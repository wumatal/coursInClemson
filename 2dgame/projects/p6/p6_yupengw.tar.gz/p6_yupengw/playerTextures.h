class PlayerTextures {
public:

private:
  
};