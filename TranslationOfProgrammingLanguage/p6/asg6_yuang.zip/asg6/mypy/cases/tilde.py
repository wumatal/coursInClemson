print ~10
print ~-10
print ~~10
