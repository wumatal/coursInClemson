print -1/2
print -1/2 - 1/2
print -1/2 + (-1/2)
print -1/2 - 1/3
print -1.5/2 + 42.3/23
print -1---------2
print -1--------2
print +++++++10
print -----8
