def f(x):
  print x
  x+=4
  print x
  y = x*6
  y+=5
  print y

f(34)
