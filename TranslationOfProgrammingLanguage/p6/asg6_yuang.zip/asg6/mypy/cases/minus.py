print 4 - 1
print 1 - 4
print 10.23 - 2
print 3 - 89.2
print 12.1214 - 23.123
print 13.12 - 32.11498
