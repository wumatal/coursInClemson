x=12

def h():
  a=3
  return x+a

print x
print h()
