x = 10
x *= 54.6
print x
