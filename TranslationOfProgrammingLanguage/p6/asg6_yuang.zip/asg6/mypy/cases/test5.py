x=12

def h():
  return x+1
print x
print h()
