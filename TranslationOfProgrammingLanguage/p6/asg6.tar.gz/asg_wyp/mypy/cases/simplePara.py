def f(x):
  print x
f(3)
