def f():
  return
print f()
