x = 7
def f():
  if x == 7:
    y = 14
  else:
    z = 21
  print y
  print x
  #print z
f()
