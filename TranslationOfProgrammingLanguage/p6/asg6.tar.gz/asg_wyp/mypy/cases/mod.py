print 5%-2  #cpp:1
print -5%-2 #cpp:-1
print 5%2   #cpp:1
print -5%2  #cpp:-1
print 15%-4 #cpp:-3
print -15%-4#cpp:-3
print 15%4  #cpp:1
print -15%4 #cpp:1
