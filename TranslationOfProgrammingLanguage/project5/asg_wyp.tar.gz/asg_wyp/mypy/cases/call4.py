def f():
  print 7

f()
f()
f()
f()
f()
