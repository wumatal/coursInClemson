x=y=7
m = n =7.7

print x
(m)
print m
x+=m

print x
m+=y

print m
y*= 5**2

print y
n//= 2.2/2

print n
y%= 2

print y
