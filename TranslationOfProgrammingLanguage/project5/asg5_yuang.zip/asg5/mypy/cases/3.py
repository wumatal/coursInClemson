x = 5.5
print 2*x + 5*x
y = 2
print 2*x - y
print 2*y - 2.5*x
print 2.5*x - 2 * y

print x * 5*y

print 2.5*x/y
print 4*x/2*y
print 5*y/2*x
