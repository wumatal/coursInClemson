print 1 + 1
print 1.5 + 2
print 3 + 1.32
print 3.3 + 8.9
