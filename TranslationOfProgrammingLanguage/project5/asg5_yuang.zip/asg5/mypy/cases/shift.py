print 100 << 2
print 2 << 10
print 100 >> 2
print 2 >> 10
