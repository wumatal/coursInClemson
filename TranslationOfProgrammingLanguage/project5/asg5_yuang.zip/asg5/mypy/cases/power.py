print 0**13
print 3.2**4.1
print 123**12.32
print 213.241**12
print 2**(0.5)
print 2**(-0.5)
