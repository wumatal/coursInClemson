x = 9

def f():
  global x
  x += 11
  print x

f()
