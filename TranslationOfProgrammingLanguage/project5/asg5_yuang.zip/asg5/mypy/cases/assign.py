x = y = 1
print x
print y

print x + y
y = 3.8
x = 4.2
print x + y

x = 1/2
print 4**x
