x = 2
x += 1.2
print x
x += x
print x
