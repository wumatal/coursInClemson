def f():
  x=0
  if x==0:
    print 99
    #x=17
    a=18
    if x:
      print x
    else:
      print x+1

f()
