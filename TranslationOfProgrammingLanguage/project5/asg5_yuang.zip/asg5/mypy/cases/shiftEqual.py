x = 10
x <<= 2
print x
x >>= 4
print x
