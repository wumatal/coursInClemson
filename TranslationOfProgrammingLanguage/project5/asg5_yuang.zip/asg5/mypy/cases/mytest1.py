print -1/2
print -1/2-1/2
print -1/2+(-1/2)
print 3/8.0*(-3/4)
print (4/7*1.2-3.34)-2*(3/4.0)
print ++++3.5-------1
print ------------1
print 2.5--------1
print 2.5+.5
print -1-------1
print -1--------1

print 15**2
print 3.6**1.0
print 2.5**3
print 2**6.0
print (-4.5)**3
print 8**(-1.0)

print 18//21
print 8.7//4.5
print 8.9//3
print 3//4.5
print -5//2
print 89.8//-2
print -24.5//-4.6

print 2%3
print 9.9%5.68
print 5.6%6
print 2.5%-4
print -7%3.2
print -15%-4
print -3.5%-8.9

x = -0.5
print x**-2
print 7.3//x
print 8%x
print x//3 + x%9.5

x = 1/2
print x
print 4**x
print 4.5**x

y=8
print x%y
print x*y-2*y+x/6
print x**(y/3)-x%2

y=-4.5
print y**3 + x//7
print x%4.8 - y//5.6
print x//y*8
print (x%y)/(y**x)

z=+++++++3
print z
print ---z

