print 33 * 44
print 92.123 * 12
print 27 * 98.123
print 726.123 * 123.928
