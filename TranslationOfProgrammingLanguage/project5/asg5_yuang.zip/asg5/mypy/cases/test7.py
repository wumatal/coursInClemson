def f():
  return 7*2

abc=123
efg=456
def g():
  print 15
  x=12

  def h():
    z=1000
    abc+efg
    #abc+g
    jkl=abc+efg
    print jkl
    print abc
    return abc+x+y+z
  y=13
  print h()

  return abc*efg

print f()
print g()
