x = 9

def f():
  # x += 11
  print x

f()
