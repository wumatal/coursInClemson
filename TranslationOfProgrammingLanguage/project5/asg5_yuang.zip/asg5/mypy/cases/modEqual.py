x = 18
x %= 5
print x
x = 24.8
y = 23
x %= y
print x
