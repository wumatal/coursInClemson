
print 24+ 30

print 15 - 50

print 99*9

print 1/2

print -1/2

print -17*7

print -5-57

print 5%57

print -7**5

print -55//7

print 5%57
