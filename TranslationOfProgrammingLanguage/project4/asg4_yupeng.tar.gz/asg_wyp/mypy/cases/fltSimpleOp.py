
print 2.4+ 3.0

print 1.5 - 5.0

print 9.9*.9

print 1/.2

print -1.0/2.0

print -1.7*7.0

print -5.0-5.7

print -9.0**0.5

print -9.0**1.0/2.0

print -9.0**(1.0/2.0)

print 9.0//7.0
